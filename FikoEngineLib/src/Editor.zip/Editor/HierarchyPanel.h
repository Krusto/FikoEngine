﻿#pragma once
#include <Core/Ref.h>
#include <Core/UUID.h>
#include <Scene/Scene.h>
#include <Scene/Entity.h>
#include <Renderer/Window.h>
namespace FikoEngine {

    class HierarchyPanel {
    public:
        HierarchyPanel();

        explicit HierarchyPanel(Ref<Window> window) : m_Window(std::move(window)) {}
        HierarchyPanel(const HierarchyPanel& other) = default;

        HierarchyPanel& operator=(const HierarchyPanel& other){
            this->m_SelectedEntity = other.m_SelectedEntity;

            return *this;
        };
        void OnImGUIRender(Scene* scene);

    private:
        void ListEntities(UUID entityID, Scene* scene);

        void DrawEntityNode(Entity entity, Scene* scene);

        Ref<Window> m_Window;
        Entity m_SelectedEntity;

    };
}