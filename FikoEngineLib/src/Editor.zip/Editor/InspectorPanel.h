﻿#pragma once
#include <Core/Ref.h>
#include <Core/UUID.h>
#include <Scene/Scene.h>
#include <Scene/Entity.h>
namespace FikoEngine {

    class InspectorPanel {
    public:
        InspectorPanel() = default;

        void OnImGUIRender(Scene* scene, WeakRef<Window> window);
    private:
        void AddComponentsMenu(Entity entity);
        template <typename T>
        void ShowComponent(std::string_view Title,Entity entity, WeakRef<Window> window,bool allowDeleteOption = true,bool allowOpenOption = true);
    };
}