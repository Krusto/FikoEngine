#include "EditorLayer.h"
#include "Core/Platform/Windows/WindowsPlatformUtils.h"
#include "AssetsPanel.hpp"
#include "Scene/SceneSerializer.hpp"
#include <Renderer/Viewport.h>
#include <imgui.h>
#include <Scene/Entity.h>
#include <Core/Ref.h>
#include <iostream>

namespace FikoEngine {
    EditorLayer::EditorLayer(const ApplicationSpec& spec) {
        m_Name = "Editor Layer";
        m_AppSpec = spec;
        m_CurrentScene = nullptr;
    }

    void EditorLayer::Init(Ref<Window> window) {
        m_Window = window;
        m_CurrentScene = SceneSerializer::Deserialize(m_AppSpec.WorkingDirectory+"/assets/testScene.yaml");

        m_HierarchyPanel = HierarchyPanel(window);
        m_InspectorPanel = InspectorPanel();
        m_AssetsPanel = AssetsPanel(window, std::filesystem::path(m_AppSpec.WorkingDirectory+"/assets"));
        m_Framebuffer = Framebuffer::Create(window->GetSpec().width,window->GetSpec().height);
    }

    void EditorLayer::OnAttach() {
    }

    void EditorLayer::OnDetach() {
        if(m_CurrentScene)
            RefUtils::RemoveFromLiveReferences(m_CurrentScene);
    }

    void EditorLayer::OnUpdate(float dt) {
        Entity primaryCamera;
        for (auto &camera: m_CurrentScene->GetEntitiesWith<CameraComponent>()) {
            if (camera.GetComponent<CameraComponent>().primary) {
                primaryCamera = camera;
                std::string Tag = primaryCamera.GetComponent<TagComponent>().Tag;
            }
        }

        if (primaryCamera.IsValid()) {
            auto entityCameraTransform = primaryCamera.GetComponent<TransformComponent>();
            auto camera = primaryCamera.GetComponent<CameraComponent>().camera;
            camera->SetPosition(entityCameraTransform.position);
            camera->SetRotation(entityCameraTransform.rotation);
            camera->Update();

            Renderer::BeginFrame();

            m_Framebuffer->Bind();
            Renderer::ClearColor(glm::vec4{0.0, 0.0, 0.0, 1.0});

            for (auto &drawable: m_CurrentScene->GetEntitiesWith<MeshComponent>()) {
                Renderer::SubmitEntity(drawable, primaryCamera.GetComponent<CameraComponent>().camera);
            }

            Renderer::Flush();

            Renderer::EndFrame();

            m_Framebuffer->Unbind();
        }

    }

    void EditorLayer::OnWindowResizeEvent(int width, int height) {

    }

    void EditorLayer::OnImGuiDraw() {
        if (ImGui::BeginMenuBar()) {
            if (ImGui::BeginMenu("File")) {
                if (ImGui::MenuItem("New Scene")){
                    auto path = FileDialogs::NewFile("");
                    if(!path.empty()){
                        SceneSerializer::Serialize(m_CurrentScene->GetHandle().GetComponent<FileComponent>().Path+"/"+
                                                   m_CurrentScene->GetHandle().GetComponent<TagComponent>().Tag+".yaml",m_CurrentScene);
                        delete m_CurrentScene;
                        m_CurrentScene = new Scene(std::filesystem::path(path).filename().stem().string(),std::filesystem::path(path).parent_path().string());
                    }
                }
                if (ImGui::MenuItem("Open Folder")) {
                    auto path = FileDialogs::OpenFolder(m_Window->GetHandle());
                    if(!path.empty())
                        m_AssetsPanel.LoadDirectory(path);
                }
                if (ImGui::MenuItem("Open Scene")) {
                    auto path = FileDialogs::OpenFile(m_Window->GetHandle(),"").string();
                    if(!path.empty()) {
                        Scene *newScene = SceneSerializer::Deserialize(path);
                        if (newScene) {
                            delete m_CurrentScene;
                            m_CurrentScene = newScene;
                        }
                    }
                }
                if (ImGui::MenuItem("Save")){
                    SceneSerializer::Serialize(m_CurrentScene->GetHandle().GetComponent<FileComponent>().Path+"/"+
                                               m_CurrentScene->GetHandle().GetComponent<TagComponent>().Tag+".yaml",m_CurrentScene);
                }
                if (ImGui::MenuItem("Save As")){
                    SceneSerializer::Serialize(FileDialogs::SaveFile(""),m_CurrentScene);
                }
                if (ImGui::MenuItem("Exit")) { SetShouldExit(true); }
                ImGui::EndMenu();
            }

            ImGui::EndMenuBar();
        }

        m_HierarchyPanel.OnImGUIRender(m_CurrentScene);
        m_AssetsPanel.OnImGUIRender(&m_CurrentScene);
        ImGui::Begin("Console");
        {
            ImGui::End();
        }

        m_InspectorPanel.OnImGUIRender(m_CurrentScene,m_Window);

        ImGui::Begin("Viewport");
        {
            ImVec2 size = ImGui::GetContentRegionAvail();
            if (m_ViewportSize.width != (u32)size.x || m_ViewportSize.height != (u32)size.y) {
                m_Framebuffer->Resize((u32) size.x, (u32) size.y);
                if (m_CurrentScene->FindEntity("EditorCamera").HasComponent<CameraComponent>()) {
                    m_CurrentScene->FindEntity("EditorCamera").GetComponent<CameraComponent>().camera->ChangeViewport(
                            (u32) size.x, (u32) size.y);
                }
            }
            ImGui::Image((void *) m_Framebuffer->GetColorAttachmentID(), size);

            ImGui::End();
        }
    }

}